To Run the project:
1. Load 'RUN_THIS_SCRIPT_SparkFundAnalysis.R' from '~/R Code/R_Scripts/'
2. Set Working Directory : 
       a. Using R Studio - Session > Set Working Directory > Choose Directory > <point to the 'R Code' folder>
       b. Using setwd() - Uncomment line#3 on the above R file. 'setwd("C:/Users/R Code")' <- use your path
3. Run the script 'RUN_THIS_SCRIPT_SparkFundAnalysis.R'
4. Verify results in the 'OutputFiles' directory.